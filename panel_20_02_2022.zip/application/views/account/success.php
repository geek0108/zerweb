<?php
/*
Copyright (c) 2020 HOSTINPL (HOSTING-RUS) https://vk.com/hosting_rus
Developed by Samir Shelenko and Alexander Zemlyanoy  (https://vk.com/id00v / https://vk.com/mrsasha082)
*/
?>
<?php echo $header ?>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	<div class="d-flex flex-column-fluid">
		<div class="container">
			<div class="card card-custom gutter-b">
				<div class="swal2-header">
					<div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
						<div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
							<span class="swal2-success-line-tip"></span> 
							<span class="swal2-success-line-long"></span>
							<div class="swal2-success-ring"></div>
								<div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
								<div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
							</div>
							<h2 class="swal2-title" id="swal2-title" style="display: flex;">Ваш баланс успешно пополнен!</h2>
						</div>
					</div>
				</div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php echo $footer ?>
