<?php echo $loginheader ?>
<?php echo $loginfooter ?>
